#!/usr/bin/env python
import sys
import buildnotifylib

buildnotifylib.BuildNotify()
